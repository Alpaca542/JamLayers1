This font is 100% FREE!
Unlimited usage, Unlimited Copies.
You just prohibited to resell this copy.

Check Out Our More COMMERCIAL FONTS:
https://www.arterfakproject.com
https://www.arterfakproject.com
https://www.arterfakproject.com

Any DONATION will be appreciated
https://www.paypal.me/ahmadramzi

For CUSTOM LICENSE, Please contact us :
arterfakproject@Gmail.com
---------------------------------------
THANK YOU FOR YOUR SUPPORT!